autowhatch = 1; inlets = 1; outlets = 1;

var halfedgesOnly, edgesOnly, facesOnly, verticesOnly;
var halfedges_size, edges_size, vertices_size, faces_size, closed;

const MAX_VERTEX_COUNT = 1000000;
const radius = 0.2;
const radius2 = radius*radius;
const force_strength = 0.000005;
const target_length = 0.05;
const smoothing_strength = 0.1;

var buff_halfedges 	= new JitterObject("jit.gpu.buffer");
var buff_edges 		= new JitterObject("jit.gpu.buffer");
var buff_faces 		= new JitterObject("jit.gpu.buffer");
var buff_vertices 	= new JitterObject("jit.gpu.buffer");
var buff_out 		= new JitterObject("jit.gpu.buffer");
var buff_forces		= new JitterObject("jit.gpu.buffer");
var buff_keys 		= new JitterObject("jit.gpu.buffer"); 
var buff_neighbors  = new JitterObject("jit.gpu.buffer"); 

var buff_halfedges_size 	= new JitterObject("jit.gpu.buffer");
var buff_edges_size 		= new JitterObject("jit.gpu.buffer");
var buff_faces_size 		= new JitterObject("jit.gpu.buffer");
var buff_vertices_size 		= new JitterObject("jit.gpu.buffer");

var comp_init_counters = new JitterObject("jit.gpu.compute");
comp_init_counters.shader = "comp_init_counters.comp";

var comp_init_hash = new JitterObject("jit.gpu.compute");
comp_init_hash.shader = "comp_init_hash.comp";

var comp_sort_keys = new JitterObject("jit.gpu.compute");
comp_sort_keys.shader = "comp_sort_keys.comp";

var comp_find_key_start = new JitterObject("jit.gpu.compute");
comp_find_key_start.shader = "comp_find_key_start.comp";

var comp_calc_repulsive_force = new JitterObject("jit.gpu.compute");
comp_calc_repulsive_force.shader = "comp_calc_repulsive_force.comp";

var comp_calc_spring_force = new JitterObject("jit.gpu.compute");
comp_calc_spring_force.shader = "comp_calc_spring_force.comp";

var comp_apply_forces = new JitterObject("jit.gpu.compute");
comp_apply_forces.shader = "comp_apply_forces.comp";

var comp_init_neighbors_count = new JitterObject("jit.gpu.compute");
comp_init_neighbors_count.shader = "comp_init_neighbors_count.comp";

var comp_calc_smoothing = new JitterObject("jit.gpu.compute");
comp_calc_smoothing.shader = "comp_calc_smoothing.comp";

var comp_apply_smoothing = new JitterObject("jit.gpu.compute");
comp_apply_smoothing.shader = "comp_apply_smoothing.comp";

var comp_test = new JitterObject("jit.gpu.compute");
comp_test.shader = "drawLines.comp";

comp_init_counters.bind("buff_halfedges_size", buff_halfedges_size.name);
comp_init_counters.bind("buff_edges_size", buff_edges_size.name);
comp_init_counters.bind("buff_faces_size", buff_faces_size.name);
comp_init_counters.bind("buff_vertices_size", buff_vertices_size.name);

comp_init_hash.bind("buff_vertices", buff_vertices.name);
comp_init_hash.bind("buff_keys", buff_keys.name);
comp_init_hash.bind("buff_vertices_size", buff_vertices_size.name);

comp_sort_keys.bind("buff_keys", buff_keys.name);

comp_find_key_start.bind("buff_keys", buff_keys.name);
comp_find_key_start.bind("buff_vertices_size", buff_vertices_size.name);

comp_calc_repulsive_force.bind("buff_vertices", buff_vertices.name);
comp_calc_repulsive_force.bind("buff_keys", buff_keys.name);
comp_calc_repulsive_force.bind("buff_forces", buff_forces.name);
comp_calc_repulsive_force.bind("buff_vertices_size", buff_vertices_size.name);

comp_calc_spring_force.bind("buff_vertices", buff_vertices.name);
comp_calc_spring_force.bind("buff_halfedges", buff_halfedges.name);
comp_calc_spring_force.bind("buff_forces", buff_forces.name);
comp_calc_spring_force.bind("buff_halfedges_size", buff_halfedges_size.name);

comp_apply_forces.bind("buff_vertices", buff_vertices.name);
comp_apply_forces.bind("buff_forces", buff_forces.name);
comp_apply_forces.bind("buff_vertices_size", buff_vertices_size.name);

comp_init_neighbors_count.bind("buff_neighbors", buff_neighbors.name);
comp_init_neighbors_count.bind("buff_forces", buff_forces.name);
comp_init_neighbors_count.bind("buff_vertices_size", buff_vertices_size.name);

comp_calc_smoothing.bind("buff_vertices", buff_vertices.name);
comp_calc_smoothing.bind("buff_halfedges", buff_halfedges.name);
comp_calc_smoothing.bind("buff_neighbors", buff_neighbors.name);
comp_calc_smoothing.bind("buff_forces", buff_forces.name);
comp_calc_smoothing.bind("buff_halfedges_size", buff_halfedges_size.name);

comp_apply_smoothing.bind("buff_vertices", buff_vertices.name);
comp_apply_smoothing.bind("buff_neighbors", buff_neighbors.name);
comp_apply_smoothing.bind("buff_forces", buff_forces.name);
comp_apply_smoothing.bind("buff_vertices_size", buff_vertices_size.name);

comp_test.bind("buff_halfedges", buff_halfedges.name);
comp_test.bind("buff_edges", buff_edges.name);
comp_test.bind("buff_faces", buff_faces.name);
comp_test.bind("buff_vertices", buff_vertices.name);
comp_test.bind("buff_out", buff_out.name);

function set_workgroups(){
	comp_init_counters.workgroups 			= [1, 1, 1];
	comp_init_hash.workgroups  	 			= [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
	comp_find_key_start.workgroups  		= [Math.ceil(MAX_VERTEX_COUNT / 128), 1, 1];
	comp_calc_repulsive_force.workgroups 	= [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
	comp_calc_spring_force.workgroups 		= [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
	comp_apply_forces.workgroups 	        = [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
    comp_init_neighbors_count.workgroups    = [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
    comp_calc_smoothing.workgroups          = [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
    comp_apply_smoothing.workgroups         = [Math.ceil(MAX_VERTEX_COUNT / 256), 1, 1];
	comp_test.workgroups 					= [Math.ceil(edges_size/256), 1, 1];
}

function set_params(){
	comp_init_counters.param("halfedges_size", halfedges_size);
	comp_init_counters.param("edges_size", edges_size);
	comp_init_counters.param("faces_size", faces_size);
	comp_init_counters.param("vertices_size", vertices_size);

	comp_init_hash.param("radius", radius);
	comp_init_hash.param("MAX_VERTEX_COUNT", MAX_VERTEX_COUNT);

	comp_calc_repulsive_force.param("radius", radius);
	comp_calc_repulsive_force.param("radius2", radius2);
	comp_calc_repulsive_force.param("MAX_VERTEX_COUNT", MAX_VERTEX_COUNT);

	comp_calc_spring_force.param("target_length", target_length);

	comp_apply_forces.param("force_strength", force_strength);

    comp_apply_smoothing.param("smoothing_strength", smoothing_strength);

	comp_test.param("halfedges_size", halfedges_size);
	comp_test.param("edges_size", edges_size);
	comp_test.param("faces_size", faces_size);
	comp_test.param("vertices_size", vertices_size);
	comp_test.param("closed", closed);
}

function set_dim(){
	buff_out.bytecount 			= edges_size * 2 * 16;
	buff_keys.bytecount 		= MAX_VERTEX_COUNT * 4 * 3;
	buff_forces.bytecount 		= MAX_VERTEX_COUNT * 4 * 3;	
    buff_neighbors.bytecount    = MAX_VERTEX_COUNT * 4;
}

function set_counters_bytecount(){
	//counters only store a 32bits uint
	buff_halfedges_size.bytecount 	= 4; 	
	buff_edges_size.bytecount 		= 4; 		
	buff_faces_size.bytecount 		= 4; 		
	buff_vertices_size.bytecount 	= 4; 				
}

function set_passnames_and_blocknames(){
	buff_halfedges.passname = comp_test.name; 	
	buff_edges.passname 	= comp_test.name; 		
	buff_faces.passname 	= comp_test.name; 		
	buff_vertices.passname 	= comp_test.name; 	
	buff_out.passname 		= comp_test.name; 	
	buff_halfedges.blockname 	= "buff_halfedges"; 		
	buff_edges.blockname 		= "buff_edges"; 				
	buff_faces.blockname 		= "buff_faces"; 				
	buff_vertices.blockname 	= "buff_vertices"; 		
	buff_out.blockname 			= "buff_out"; 					
}

function resize_buffers(vertices_size){

	let scaling_factor = Math.ceil(MAX_VERTEX_COUNT / vertices_size);
	//enlarge the buffers to include more geometry data
	buff_halfedges.bytecount 	= scaling_factor * buff_halfedges.bytecount; 	
	buff_edges.bytecount 		= scaling_factor * buff_edges.bytecount; 			
	buff_faces.bytecount 		= scaling_factor * buff_faces.bytecount; 			
	buff_vertices.bytecount 	= scaling_factor * buff_vertices.bytecount; 					
}

function nextPowerOfTwo(N){ //bit-twiddling
    if (N <= 1){ return 1; }
    N--;
    N |= N >> 1; N |= N >> 2; N |= N >> 4; N |= N >> 8; N |= N >> 16;
    return N + 1;
}

function dictionary(dictName) {

	//reference dictionary
    const src = new Dict(dictName);
    const root = JSON.parse(src.stringify());
    const geom = root.geomlist[0];

    halfedges_size 	= geom.halfedges_size;
    edges_size 		= geom.edges_size;
    vertices_size 	= geom.vertices_size;
    faces_size 		= geom.faces_size;
    closed 			= geom.closed;

    //set constants
    set_workgroups();
    set_params();
    set_dim();
    set_passnames_and_blocknames();

    //parse dictionary
    halfedgesOnly 	= new Dict();
    edgesOnly 		= new Dict();
    facesOnly 		= new Dict();
    verticesOnly 	= new Dict();

    halfedgesOnly.set("halfedges", geom.halfedges);
    edgesOnly.set("edges", geom.edges);
    facesOnly.set("faces", geom.faces);
    verticesOnly.set("vertices", geom.vertices.map(v => ({ point: v.point })));

    //fill buffers
    buff_halfedges.dictionary(halfedgesOnly.name);
    buff_edges.dictionary(edgesOnly.name);
    buff_faces.dictionary(facesOnly.name);
    buff_vertices.dictionary(verticesOnly.name);

    resize_buffers(geom.vertices_size);

    set_counters_bytecount();

    //init counters
    comp_init_counters.bang();
}

function bang(){

    //compute hash key
    comp_init_hash.bang();

    //Sort by ascending key
    const np2 = nextPowerOfTwo(MAX_VERTEX_COUNT);
    const numPairs = np2 / 2;
    const numStages = Math.log2(np2);
    
    comp_sort_keys.workgroups = [Math.ceil(numPairs / 128), 1, 1];
    comp_sort_keys.param("pc.numValues", MAX_VERTEX_COUNT);

    for(let stageIndex = 0; stageIndex < numStages; stageIndex++){
        for(let stepIndex = 0; stepIndex < stageIndex + 1; stepIndex++){
            
            let groupWidth = 1 << (stageIndex - stepIndex);
            let groupHeight = 2 * groupWidth - 1;
            comp_sort_keys.param("pc.groupWidth", groupWidth);
            comp_sort_keys.param("pc.groupHeight", groupHeight);
            comp_sort_keys.param("pc.stepIndex", stepIndex);
            comp_sort_keys.bang();
        }
    }

    //Find key start
    comp_find_key_start.bang();

    //compute the repulsive force
    comp_calc_repulsive_force.bang();

    //compute the spring force
    comp_calc_spring_force.bang();

    //apply forces
    comp_apply_forces.bang();

    //init the neighbors count
    comp_init_neighbors_count.bang();

    //compute forces for smoothing
    comp_calc_smoothing.bang();

    //apply smoothing
    comp_apply_smoothing.bang();

    comp_test.bang();

    outlet(0, "source", buff_out.name);
    outlet(0, "bang");
}